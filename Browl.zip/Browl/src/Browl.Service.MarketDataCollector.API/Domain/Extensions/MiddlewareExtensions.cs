﻿using Microsoft.OpenApi.Models;
using System.Reflection;

namespace Browl.Service.MarketDataCollector.API.Domain.Extensions
{
    public static class MiddlewareExtensions
    {
        public static IServiceCollection AddCustomSwagger(this IServiceCollection services)
        {
            services.AddSwaggerGen(cfg =>
            {
                cfg.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "Browl",
                    Version = "v1",
                    Description = "API for Market Data Collection",
                    Contact = new OpenApiContact
                    {
                        Name = "ROndinele GUimaães",
                        Url = new Uri("https://github.com/RondineleG/Browl")
                    },
                    License = new OpenApiLicense
                    {
                        Name = "MIT",
                    },
                });

                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                cfg.IncludeXmlComments(xmlPath);
            });
            return services;
        }

        public static IApplicationBuilder UseCustomSwagger(this IApplicationBuilder app)
        {
            app.UseSwagger().UseSwaggerUI(options =>
            {
                options.SwaggerEndpoint("/swagger/v1/swagger.json", "Browl.Service.MarketDataCollector.API");
                options.DocumentTitle = "Browl.Service.MarketDataCollector.API";
            });
            return app;
        }
    }
}
