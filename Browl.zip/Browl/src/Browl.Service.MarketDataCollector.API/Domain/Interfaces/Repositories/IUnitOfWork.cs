namespace Browl.Service.MarketDataCollector.API.Domain.Interfaces.Repositories
{
    public interface IUnitOfWork
    {
        Task CompleteAsync();
    }
}