﻿global using Browl.Service.MarketDataCollector.API.Domain.Entities;
global using Browl.Service.MarketDataCollector.API.Domain.Models.Queries;