using AutoMapper;
using Browl.Service.MarketDataCollector.API.Application.Resources;
using Browl.Service.MarketDataCollector.API.Domain.Extensions;

namespace Browl.Service.MarketDataCollector.API.Infrastructure.Mapping
{
    public class ModelToResourceProfile : Profile
    {
        public ModelToResourceProfile()
        {
            CreateMap<Category, CategoryResource>();

            CreateMap<Product, ProductResource>()
                .ForMember(src => src.UnitOfMeasurement,
                           opt => opt.MapFrom(src => src.UnitOfMeasurement.ToDescriptionString()));

            CreateMap<QueryResult<Product>, QueryResultResource<ProductResource>>();
        }
    }
}