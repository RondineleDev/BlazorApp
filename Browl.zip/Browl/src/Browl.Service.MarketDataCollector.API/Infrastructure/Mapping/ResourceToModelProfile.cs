using AutoMapper;
using Browl.Service.MarketDataCollector.API.Application.Resources;
using Browl.Service.MarketDataCollector.API.Domain.Enums;

namespace Browl.Service.MarketDataCollector.API.Infrastructure.Mapping
{
    public class ResourceToModelProfile : Profile
    {
        public ResourceToModelProfile()
        {
            CreateMap<SaveCategoryResource, Category>();

            CreateMap<SaveProductResource, Product>()
                .ForMember(src => src.UnitOfMeasurement, opt => opt.MapFrom(src => (UnitOfMeasurement)src.UnitOfMeasurement));

            CreateMap<ProductsQueryResource, ProductsQuery>();
        }
    }
}