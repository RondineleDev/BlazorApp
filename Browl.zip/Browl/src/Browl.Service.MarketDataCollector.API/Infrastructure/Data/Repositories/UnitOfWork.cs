using Browl.Service.MarketDataCollector.API.Domain.Interfaces.Repositories;
using Browl.Service.MarketDataCollector.API.Infrastructure.Data.Contexts;

namespace Browl.Service.MarketDataCollector.API.Infrastructure.Data.Repositories
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly AppDbContext _context;

        public UnitOfWork(AppDbContext context)
        {
            _context = context;
        }

        public async Task CompleteAsync()
        {
            await _context.SaveChangesAsync();
        }
    }
}