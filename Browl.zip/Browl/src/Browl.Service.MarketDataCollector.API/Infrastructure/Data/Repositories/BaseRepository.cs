using Browl.Service.MarketDataCollector.API.Infrastructure.Data.Contexts;

namespace Browl.Service.MarketDataCollector.API.Infrastructure.Data.Repositories
{
    public abstract class BaseRepository
    {
        protected readonly AppDbContext _context;

        public BaseRepository(AppDbContext context)
        {
            _context = context;
        }
    }
}