namespace Browl.Service.MarketDataCollector.API.Infrastructure.Cache
{
    public enum CacheKeys : byte
    {
        CategoriesList,
        ProductsList,
    }
}