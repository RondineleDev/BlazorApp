namespace Browl.Service.MarketDataCollector.API.Application.Resources
{
    public record ProductsQueryResource : QueryResource
    {
        public int CategoryId { get; init; }
    }
}