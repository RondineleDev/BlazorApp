﻿using Browl.Service.MarketDataCollector.API.Application.Services;
using Browl.Service.MarketDataCollector.API.Controllers.Configurations;
using Browl.Service.MarketDataCollector.API.Domain.Extensions;
using Browl.Service.MarketDataCollector.API.Domain.Interfaces.Repositories;
using Browl.Service.MarketDataCollector.API.Domain.Interfaces.Services;
using Browl.Service.MarketDataCollector.API.Infrastructure.Data.Contexts;
using Browl.Service.MarketDataCollector.API.Infrastructure.Data.Repositories;
using Microsoft.EntityFrameworkCore;

namespace Browl.Service.MarketDataCollector.API
{
    public class Startup
    {
        private readonly IConfiguration Configuration;
        public Startup(IConfiguration configuration) => Configuration = configuration;

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMemoryCache();
            services.AddCustomSwagger();
            services.Configure<RouteOptions>(options => options.LowercaseUrls = true);
            services.AddControllers().ConfigureApiBehaviorOptions(options =>
            {
                options.InvalidModelStateResponseFactory = InvalidModelStateResponseFactory.ProduceErrorResponse;
            });
            services.AddDbContext<AppDbContext>(options =>
            {
                options.UseInMemoryDatabase(Configuration.GetConnectionString("memory") ?? "data-in-memory");
            });
            services.AddScoped<ICategoryRepository, CategoryRepository>();
            services.AddScoped<IProductRepository, ProductRepository>();
            services.AddScoped<IUnitOfWork, UnitOfWork>();
            services.AddScoped<ICategoryService, CategoryService>();
            services.AddScoped<IProductService, ProductService>();
            services.AddAutoMapper(typeof(Startup));
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseCustomSwagger();
            app.UseRouting();
            app.UseAuthorization();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}